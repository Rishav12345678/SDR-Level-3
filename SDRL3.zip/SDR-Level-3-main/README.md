# SDR-Level-3

This is the Project made for Indian Army Hackathon 

Softwares Used: GNU Radio and companion, SDRSharp, SDRAngel, Adobe Audition, Audacity

Devices: RTL-SDR, HackRF One, BX Amp

Made By- Rishav Baisla
